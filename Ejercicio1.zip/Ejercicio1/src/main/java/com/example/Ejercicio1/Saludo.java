package com.example.Ejercicio1;

public class Saludo {

    public String imprimirSaludo(){
        return "Hola buenos dias";
    }
}
